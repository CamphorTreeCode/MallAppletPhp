<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%postage_rules}}".
 *
 * @property integer $id
 * @property integer $store_id
 * @property string $name
 * @property integer $express_id
 * @property string $detail
 * @property integer $addtime
 * @property integer $is_enable
 * @property integer $is_delete
 * @property string $express
 */
class PostageRules extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%postage_rules}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['store_id', 'name', 'express_id', 'detail'], 'required'],
            [['store_id', 'express_id', 'addtime', 'is_enable', 'is_delete'], 'integer'],
            [['detail'], 'string'],
            [['name', 'express'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'store_id' => 'Store ID',
            'name' => '名称',
            'express_id' => '物流公司',
            'detail' => '规则详细',
            'addtime' => 'Addtime',
            'is_enable' => '是否启用：0=否，1=是',
            'is_delete' => 'Is Delete',
            'express' => '快递公司',
        ];
    }

    public function getExpress()
    {
        return $this->hasOne(Express::className(), ['id' => 'express_id']);
    }

    public static function getExpressPrice($store_id, $province_id)
    {
        $postage_rules = PostageRules::findOne([
            'store_id' => $store_id,
            'is_delete' => 0,
            'is_enable' => 1,
        ]);
        if (!$postage_rules)
            return 0.00;
        $price = 0.00;
        $list = json_decode($postage_rules->detail);
        foreach ($list as $i => $item) {
            $in_array = false;
            foreach ($item->province_list as $j => $province) {
                if ($province->id == $province_id) {
                    $in_array = true;
                    break;
                }
            }
            if ($in_array) {
                $price = $item->price;
                break;
            }
        }
        return $price;
    }
}
