<?php
defined('YII_RUN') or exit('Access Denied');
use yii\widgets\LinkPager;

$urlManager = Yii::$app->urlManager;
$this->title = '商城首页轮播图';
$this->params['active_nav_group'] = 1;
?>

<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>

<div class="main-body p-3">
    <a href="<?= $urlManager->createAbsoluteUrl(['mch/store/slide-edit']) ?>" class="btn btn-primary mb-3">
        <i class="iconfont icon-playlistadd"></i>添加轮播图</a>
    <div style="overflow-x: hidden">
        <div class="row">
            <?php foreach ($list as $index => $value): ?>
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="card mb-3">
                        <div class="card-img-top" data-responsive="750:400" style="background-image: url(<?= $value['pic_url'] ?>);background-size: cover;background-position: center"></div>
                        <div class="card-body p-3">
                            <p>标题：<?= $value['title'] ?></p>
                            <div>链接：<?= $value['page_url'] ?></div>
                        </div>

                        <div class="card-footer text-muted">
                            <a class="btn btn-sm btn-primary"
                               href="<?= $urlManager->createAbsoluteUrl(['mch/store/slide-edit', 'id' => $value['id']]) ?>">修改</a>
                            <a class="btn btn-sm btn-danger del"
                               href="<?= $urlManager->createAbsoluteUrl(['mch/store/slide-del', 'id' => $value['id']]) ?>">删除</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <nav aria-label="Page navigation example">
        <?php echo LinkPager::widget([
            'pagination' => $pagination,
            'prevPageLabel' => '上一页',
            'nextPageLabel' => '下一页',
            'firstPageLabel' => '首页',
            'lastPageLabel' => '尾页',
            'maxButtonCount' => 5,
            'options' => [
                'class' => 'pagination',
            ],
            'prevPageCssClass' => 'page-item',
            'pageCssClass' => "page-item",
            'nextPageCssClass' => 'page-item',
            'firstPageCssClass' => 'page-item',
            'lastPageCssClass' => 'page-item',
            'linkOptions' => [
                'class' => 'page-link',
            ],
            'disabledListItemSubTagOptions' => ['tag' => 'a', 'class' => 'page-link'],
        ])
        ?>
    </nav>
</div>
<script>
    $(document).on('click', '.del', function () {
        if (confirm("是否删除？")) {
            $.ajax({
                url: $(this).attr('href'),
                type: 'get',
                dataType: 'json',
                success: function (res) {
                    alert(res.msg);
                    if (res.code == 0) {
                        window.location.reload();
                    }
                }
            });
        }
        return false;
    });
</script>