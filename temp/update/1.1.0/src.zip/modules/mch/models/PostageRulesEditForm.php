<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/7/3
 * Time: 14:37
 */

namespace app\modules\mch\models;


use app\models\PostageRules;

/**
 * @property PostageRules $postage_rules
 */
class PostageRulesEditForm extends Model
{
    public $postage_rules;

    public $name;
    public $express_id;
    public $express;
    public $detail;

    public function rules()
    {
        return [
            [['name',], 'required'],
            [['express'], 'trim'],
            [['express_id',], 'default', 'value' => 0],
            [['detail',], 'safe'],
        ];
    }

    public function save()
    {
        if (!$this->validate())
            return $this->getModelError();
        $this->detail = json_encode($this->detailFormat($this->detail), JSON_UNESCAPED_UNICODE);
        $this->postage_rules->attributes = $this->attributes;
        if ($this->postage_rules->isNewRecord) {
            $this->postage_rules->is_delete = 0;
            $this->postage_rules->addtime = time();
        }
        if ($this->postage_rules->save())
            return [
                'code' => 0,
                'msg' => '保存成功',
            ];
        else
            return $this->getModelError($this->postage_rules);
        //\Yii::$app->response->redirect()->send();
    }

    private function detailFormat($detail)
    {
        if (!is_array($detail))
            return [];
        $new_detail = [];
        foreach ($detail as $item) {
            $new_item = [
                'price' => isset($item['price']) ? intval($item['price']) : 0,
                'province_list' => [],
            ];
            foreach ($item['province_list'] as $province) {
                $new_item['province_list'][] = [
                    'id' => isset($province['id']) ? $province['id'] : 0,
                    'name' => isset($province['name']) ? $province['name'] : '',
                ];
            }
            $new_detail[] = $new_item;
        }
        return $new_detail;
    }
}