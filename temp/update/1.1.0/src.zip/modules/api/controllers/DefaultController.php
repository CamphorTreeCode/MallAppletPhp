<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/6/19
 * Time: 15:15
 */

namespace app\modules\api\controllers;


use app\models\Banner;
use app\models\Cat;
use app\models\FormId;
use app\models\Goods;
use app\models\Store;
use app\models\UploadForm;
use app\modules\api\behaviors\LoginBehavior;
use app\modules\api\models\CatListForm;
use app\modules\api\models\DistrictForm;
use app\modules\api\models\GoodsAttrInfoForm;
use app\modules\api\models\GoodsForm;
use app\modules\api\models\GoodsListForm;
use app\modules\api\models\IndexForm;
use yii\data\Pagination;
use yii\helpers\VarDumper;

class DefaultController extends Controller
{
    public function behaviors()
    {
        return [
        ];
    }

    /**
     * 首页接口
     */
    public function actionIndex()
    {
        $form = new IndexForm();
        $form->store_id = $this->store->id;
        $this->renderJson($form->search());
    }

    /**
     * 分类列表
     */
    public function actionCatList()
    {
        $form = new CatListForm();
        $form->attributes = \Yii::$app->request->get();
        $form->store_id = $this->store->id;
        $this->renderJson($form->search());
    }

    /**
     * 商品列表
     */
    public function actionGoodsList()
    {
        $form = new GoodsListForm();
        $form->attributes = \Yii::$app->request->get();
        $form->store_id = $this->store->id;
        $this->renderJson($form->search());
    }

    /**
     * 商品详情
     */
    public function actionGoods()
    {
        $form = new GoodsForm();
        $form->attributes = \Yii::$app->request->get();
        if (!\Yii::$app->user->isGuest) {
            $form->user_id = \Yii::$app->user->id;
        }
        $this->renderJson($form->search());
    }

    /**
     * 省市区数据
     */
    public function actionDistrict()
    {
        $form = new DistrictForm();
        $this->renderJson($form->search());
    }


    public function actionGoodsAttrInfo()
    {
        $form = new GoodsAttrInfoForm();
        $form->attributes = \Yii::$app->request->get();
        $this->renderJson($form->search());
    }

    public function actionStore()
    {
        $this->renderJson([
            'code' => 0,
            'msg' => 'success',
            'data' => [
                'store_name' => $this->store->name,
                'contact_tel' => $this->store->contact_tel,
                'show_customer_service' => $this->store->show_customer_service,
                'store' => (object)[
                    'id' => $this->store->id,
                    'name' => $this->store->name,
                    'copyright' => $this->store->copyright,
                    'copyright_pic_url' => $this->store->copyright_pic_url,
                    'contact_tel' => $this->store->contact_tel,
                    'show_customer_service' => $this->store->show_customer_service,
                ],
            ],
        ]);
    }

    public function actionUploadImage()
    {
        $form = new UploadForm();
        $this->renderJson($form->saveImage('image'));
    }
}