<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/7/18
 * Time: 12:11
 */

namespace app\modules\api\models;


use app\models\FormId;
use app\models\Goods;
use app\models\Order;
use app\models\OrderDetail;
use app\models\User;
use yii\helpers\VarDumper;

/**
 * @property User $user
 */
class OrderPayDataForm extends Model
{
    public $store_id;
    public $order_id;
    public $pay_type;
    public $user;

    public function rules()
    {
        return [
            [['order_id', 'pay_type',], 'required'],
            [['pay_type'], 'in', 'range' => ['ALIPAY', 'WECHAT_PAY']],
        ];
    }

    public function search()
    {
        if (!$this->validate())
            return $this->getModelError();
        $order = Order::findOne([
            'store_id' => $this->store_id,
            'id' => $this->order_id,
        ]);
        if (!$order)
            return [
                'code' => 1,
                'msg' => '订单不存在',
            ];
        $goods_names = '';
        $goods_list = OrderDetail::find()->alias('od')->leftJoin(['g' => Goods::tableName()], 'g.id=od.goods_id')->where([
            'od.order_id' => $order->id,
            'od.is_delete' => 0,
        ])->select('g.name')->asArray()->all();
        foreach ($goods_list as $goods)
            $goods_names .= $goods['name'] . ';';
        $goods_names = mb_substr($goods_names, 0, 32);
        if ($this->pay_type == 'WECHAT_PAY') {
            $wechat = $this->getWechat();
            $res = $wechat->pay->unifiedOrder([
                'body' => $goods_names,
                'out_trade_no' => $order->order_no,
                'total_fee' => $order->pay_price * 100,
                'notify_url' => \Yii::$app->request->hostInfo . \Yii::$app->request->baseUrl . '/pay-notify.php',
                'trade_type' => 'JSAPI',
                'openid' => $this->user->wechat_open_id,
            ]);
            if (!$res)
                return [
                    'code' => 1,
                    'msg' => '支付失败',
                ];
            if ($res['return_code'] != 'SUCCESS' || $res['result_code'] != 'SUCCESS') {
                return [
                    'code' => 1,
                    'msg' => '支付失败，' . (isset($res['return_msg']) ? $res['return_msg'] : ''),
                ];
            }

            //记录prepay_id发送模板消息用到
            FormId::addFormId([
                'store_id' => $this->store_id,
                'user_id' => $this->user->id,
                'wechat_open_id' => $this->user->wechat_open_id,
                'form_id' => $res['prepay_id'],
                'type' => 'prepay_id',
                'order_no' => $order->order_no,
            ]);

            $pay_data = [
                'appId' => $wechat->appId,
                'timeStamp' => '' . time(),
                'nonceStr' => md5(uniqid()),
                'package' => 'prepay_id=' . $res['prepay_id'],
                'signType' => 'MD5',
            ];
            $pay_data['paySign'] = $wechat->pay->makeSign($pay_data);
            return [
                'code' => 0,
                'msg' => 'success',
                'data' => (object)$pay_data,
            ];
        }
    }
}