<?php
defined('IN_IA') or define('IN_IA', true);
require __DIR__ . '/../../../../data/config.php';
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=' . $config['db']['master']['host'] . ';dbname=' . $config['db']['master']['database'],
    'username' => $config['db']['master']['username'],
    'password' => $config['db']['master']['password'],
    'charset' => 'utf8',
    'tablePrefix' => 'hjmall_',
];
