<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/6/19
 * Time: 16:52
 */
$urlManager = Yii::$app->urlManager;
$this->title = '商城设置';
$this->params['active_nav_group'] = 1;
?>

<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>

<div class="main-body p-3">
    <form class="form auto-submit-form" method="post" autocomplete="off">
        <div class="form-title">商城设置</div>
        <div class="form-body">
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">商城名称</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="name" value="<?= $store->name ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">小程序AppId</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="app_id" value="<?= $wechat_app->app_id ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">小程序AppSecret</label>
                </div>
                <div class="col-9">
                    <?php if ($wechat_app->app_secret): ?>
                        <div class="input-hide">
                            <input class="form-control" type="text" name="app_secret"
                                   value="<?= $wechat_app->app_secret ?>">
                            <div class="tip-block">已隐藏AppSecret，点击查看或编辑</div>
                        </div>
                    <?php else: ?>
                        <input class="form-control" type="text" name="app_secret"
                               value="<?= $wechat_app->app_secret ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">微信支付商户号</label>
                </div>
                <div class="col-9">
                    <input autocomplete="off" class="form-control" type="text" name="mch_id"
                           value="<?= $wechat_app->mch_id ?>">
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">微信支付key</label>
                </div>
                <div class="col-9">
                    <?php if ($wechat_app->key): ?>
                        <div class="input-hide">
                            <input class="form-control" type="text" name="key"
                                   value="<?= $wechat_app->key ?>">
                            <div class="tip-block">已隐藏Key，点击查看或编辑</div>
                        </div>
                    <?php else: ?>
                        <input class="form-control" type="text" name="key"
                               value="<?= $wechat_app->key ?>">
                    <?php endif; ?>

                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">微信支付apiclient_cert.pem</label>
                </div>
                <div class="col-9">
                    <?php if ($wechat_app->cert_pem): ?>
                        <div class="input-hide">
                            <textarea class="form-control" type="text"
                                      rows="5"
                                      placeholder="请将apiclient_cert.pem文件里面的内容粘贴到此处"
                                      name="cert_pem"><?= $wechat_app->cert_pem ?></textarea>
                            <div class="tip-block">已隐藏Key，点击查看或编辑</div>
                        </div>
                    <?php else: ?>
                        <textarea class="form-control" type="text"
                                  rows="5"
                                  placeholder="请将apiclient_cert.pem文件里面的内容粘贴到此处"
                                  name="cert_pem"><?= $wechat_app->cert_pem ?></textarea>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">微信支付apiclient_key.pem</label>
                </div>
                <div class="col-9">
                    <?php if ($wechat_app->key_pem): ?>
                        <div class="input-hide">
                            <textarea class="form-control" type="text"
                                      rows="5"
                                      placeholder="请将apiclient_cert.pem文件里面的内容粘贴到此处"
                                      name="key_pem"><?= $wechat_app->key_pem ?></textarea>
                            <div class="tip-block">已隐藏Key，点击查看或编辑</div>
                        </div>
                    <?php else: ?>
                        <textarea class="form-control" type="text"
                                  rows="5"
                                  placeholder="请将apiclient_key.pem文件里面的内容粘贴到此处"
                                  name="key_pem"><?= $wechat_app->key_pem ?></textarea>
                    <?php endif; ?>

                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">通知设置</label>
                </div>
                <div class="col-9">
                    <div class="card">
                        <div class="card-block">
                            <div class="mb-3">
                                <label>发货模板消息id</label>
                                <input class="form-control" type="text" name="order_send_tpl"
                                       value="<?= $store->order_send_tpl ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">联系电话</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="contact_tel"
                           value="<?= $store->contact_tel ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">开启在线客服</label>
                </div>
                <div class="col-9">
                    <div class="pt-1">
                        <label class="custom-control custom-radio">
                            <input id="radio1" <?= $store->show_customer_service == 1 ? 'checked' : null ?>
                                   value="1"
                                   name="show_customer_service" type="radio" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description">开启</span>
                        </label>
                        <label class="custom-control custom-radio">
                            <input id="radio2" <?= $store->show_customer_service == 0 ? 'checked' : null ?>
                                   value="0"
                                   name="show_customer_service" type="radio" class="custom-control-input">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description">关闭</span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">底部版权图片</label>
                </div>
                <div class="col-9">
                    <?= \app\widgets\ImageUpload::widget([
                        'name' => 'copyright_pic_url',
                        'value' => $store->copyright_pic_url,
                        'width' => 120,
                        'height' => 60,
                    ]) ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">底部版权文字</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="copyright"
                           value="<?= $store->copyright ?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">底部版权页面链接</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="copyright_url"
                           value="<?= $store->copyright_url ?>">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-9 offset-sm-3">
                    <div class="text-danger form-error mb-3" style="display: none">错误信息</div>
                    <div class="text-success form-success mb-3" style="display: none">成功信息</div>
                    <a class="btn btn-primary submit-btn" href="javascript:">保存</a>
                </div>
            </div>
        </div>

    </form>

</div>