<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/29
 * Time: 10:49
 */

$urlManager = Yii::$app->urlManager;
$this->title = '商品编辑';
$staticBaseUrl = Yii::$app->request->baseUrl . '/statics';
$this->params['active_nav_group'] = 2;
$returnUrl = Yii::$app->request->referrer;
if (!$returnUrl)
    $returnUrl = $urlManager->createUrl(['mch/goods/goods']);
?>

<style>
    .cat-box {
        border: 1px solid rgba(0, 0, 0, .15);
    }

    .cat-box .row {
        margin: 0;
        padding: 0;
    }

    .cat-box .col-6 {
        padding: 0;
    }

    .cat-box .cat-list {
        border-right: 1px solid rgba(0, 0, 0, .15);
        overflow-x: hidden;
        overflow-y: auto;
        height: 10rem;
    }

    .cat-box .cat-item {
        border-bottom: 1px solid rgba(0, 0, 0, .1);
        padding: .5rem 1rem;
        display: block;
        margin: 0;
    }

    .cat-box .cat-item:last-child {
        border-bottom: none;
    }

    .cat-box .cat-item:hover {
        background: rgba(0, 0, 0, .05);
    }

    .cat-box .cat-item.active {
        background: rgb(2, 117, 216);
        color: #fff;
    }

    .cat-box .cat-item input {
        display: none;
    }
</style>

<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <a class="breadcrumb-item" href="<?= $returnUrl ?>">商品管理</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>

<div class="main-body p-3" id="page">
    <form class="form auto-submit-form" method="post" autocomplete="off" data-return="<?= $returnUrl ?>">
        <div class="form-title">商品编辑</div>
        <div class="form-body">


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">商品分类</label>
                </div>
                <div class="col-9">
                    <div class="input-group">
                        <input readonly class="form-control cat-name" value="<?= $goods->cat->name ?>">
                        <input type="hidden" name="model[cat_id]" class="form-control cat-id"
                               value="<?= $goods->cat->id ?>">
                        <span class="input-group-btn">
                            <a class="btn btn-secondary" href="javascript:" data-toggle="modal" data-target="#catModal">选择分类</a>
                        </span>
                    </div>
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">商品名称</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="model[name]" value="<?= $goods['name'] ?>">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class="col-form-label required">商品图片</label>
                </div>
                <div class="col-9">
                    <?php if ($goods->goodsPicList):foreach ($goods->goodsPicList as $goods_pic): ?>
                        <?php $goods_pic_list[] = $goods_pic->pic_url ?>
                    <?php endforeach;
                    else:$goods_pic_list = [];endif; ?>
                    <?= \app\widgets\ImageUpload::widget([
                        'name' => 'model[goods_pic_list][]',
                        'value' => $goods_pic_list,
                        'multiple' => true,
                        'width' => 750,
                        'height' => 700,
                    ]) ?>
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">售价</label>
                </div>
                <div class="col-9">
                    <div class="input-group">
                        <input type="number" step="0.01" class="form-control"
                               name="model[price]" min="0.01" value="<?= $goods['price'] ? $goods['price'] : 1 ?>">
                        <span class="input-group-addon">元</span>
                    </div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">原价</label>
                </div>
                <div class="col-9">
                    <input type="number" style="width:100%" step="0.01" class="form-control"
                           name="model[original_price]" min="0"
                           value="<?= $goods['original_price'] ? $goods['original_price'] : 1 ?>">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">服务内容</label>
                </div>
                <div class="col-9">
                    <input class="form-control" name="model[service]" value="<?= $goods['service'] ?>">
                    <div class="fs-sm text-muted">例子：正品保障,极速发货,7天退换货。多个请使用英文逗号<kbd>,</kbd>分隔</div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">图文详情</label>
                </div>
                <div class="col-9">
                        <textarea id="editor" style="width: 100%"
                                  name="model[detail]"><?= $goods['detail'] ?></textarea>
                </div>
            </div>


            <div class="form-group row">
                <div class="col-9 offset-sm-3">
                    <div class="text-danger form-error mb-3" style="display: none">错误信息</div>
                    <div class="text-success form-success mb-3" style="display: none">成功信息</div>
                    <a class="btn btn-primary submit-btn" href="javascript:">保存</a>
                </div>
            </div>
        </div>

    </form>


    <!-- 选择分类 -->
    <div class="modal fade" id="catModal" tabindex="-1" role="dialog" aria-labelledby="catModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <b>选择分类</b>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="cat-box">
                        <div class="row">
                            <div class="col-6">
                                <div class="cat-list parent-cat-list">
                                    <?php foreach ($cat_list as $index => $cat): ?>
                                        <label class="cat-item <?= $index == 0 ? 'active' : '' ?>">
                                            <?= $cat->name ?>
                                            <input value="<?= $cat->id ?>"
                                                <?= $index == 0 ? 'checked' : '' ?>
                                                   type="radio"
                                                   name="model[cat_id]">
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="cat-list">
                                    <label class="cat-item" v-for="sub_cat in sub_cat_list">
                                        {{sub_cat.name}}
                                        <input v-bind:value="sub_cat.id" type="radio" name="model[cat_id]">
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                    <button type="button" class="btn btn-primary cat-confirm">确认</button>
                </div>
            </div>
        </div>
    </div>

</div>


<script src="<?= Yii::$app->request->baseUrl ?>/statics/ueditor/ueditor.config.js"></script>
<script src="<?= Yii::$app->request->baseUrl ?>/statics/ueditor/ueditor.all.min.js"></script>
<script>
    var page = new Vue({
        el: "#page",
        data: {
            sub_cat_list: [],
            goods_attr_list: [
                {
                    attr_name: "红色",
                    attr_id: 1,
                    sub_attr_list: [
                        {
                            attr_name: "S",
                            attr_id: 2,
                        },
                        {
                            attr_name: "M",
                            attr_id: 2,
                        }
                    ],
                },
            ],
        }
    });
    var ue = UE.getEditor('editor', {
        serverUrl: "<?=$urlManager->createUrl(['upload/ue'])?>",
    });

    $(document).on("change", ".cat-item input", function () {
        if ($(this).prop("checked")) {
            $(".cat-item").removeClass("active");
            $(this).parent(".cat-item").addClass("active");
        } else {
            $(this).parent(".cat-item").removeClass("active");
        }
    });
    $(document).on("change", ".parent-cat-list input", function () {
        getSubCatList();
    });

    $(document).on("click", ".cat-confirm", function () {
        var cat_name = $.trim($(".cat-item.active").text());
        var cat_id = $(".cat-item.active input").val();
        console.log(cat_name);
        console.log(cat_id);
        if (cat_name && cat_id) {
            $(".cat-name").val(cat_name);
            $(".cat-id").val(cat_id);
        }
        $("#catModal").modal("hide");
    });


    function getSubCatList() {
        var parent_id = $(".parent-cat-list input:checked").val();
        page.sub_cat_list = [];
        $.ajax({
            url: "<?=$urlManager->createUrl(['mch/goods/get-cat-list'])?>",
            data: {
                parent_id: parent_id,
            },
            success: function (res) {
                if (res.code == 0) {
                    page.sub_cat_list = res.data;
                }
            }
        });
    }
    getSubCatList();


    $(document).on("change", ".attr-select", function () {
        var name = $(this).attr("data-name");
        var id = $(this).val();
        if ($(this).prop("checked")) {
        } else {
        }
    });
</script>