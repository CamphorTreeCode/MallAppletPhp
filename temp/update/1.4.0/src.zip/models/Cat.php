<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%cat}}".
 *
 * @property integer $id
 * @property integer $store_id
 * @property integer $parent_id
 * @property string $name
 * @property string $pic_url
 * @property integer $sort
 * @property integer $addtime
 * @property integer $is_delete
 * @property string $big_pic_url
 */
class Cat extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%cat}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['store_id', 'name',], 'required'],
            [['store_id', 'parent_id', 'sort', 'addtime', 'is_delete'], 'integer'],
            [['pic_url', 'big_pic_url'], 'string'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'store_id' => '商城id',
            'parent_id' => '上级分类id',
            'name' => '分类名称',
            'pic_url' => '分类图片url',
            'sort' => '排序，升序',
            'addtime' => 'Addtime',
            'is_delete' => 'Is Delete',
            'big_pic_url' => '分类大图',
        ];
    }

    /**
     * @return array
     */
    public function saveCat()
    {
        if ($this->validate()) {
            if ($this->save(false)) {
                return [
                    'code' => 0,
                    'msg' => '成功'
                ];
            } else {
                return [
                    'code' => 1,
                    'msg' => '失败'
                ];
            }
        } else {
            return (new Model())->getModelError($this);
        }
    }

    public function getParent()
    {
        return $this->hasOne(Cat::className(), ['id' => 'parent_id']);
    }

    public function getChildrenList()
    {
        return $this->hasMany(Cat::className(), ['parent_id' => 'id'])->where(['is_delete' => 0])->orderBy('sort,addtime DESC');
    }
}
