var api = require('../../api.js');
var app = getApp();
var share_count = 0;
Page({
    data: {},

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.loadData(options);
        var page = this;
        var parent_id = 0;
        var user_id = options.user_id;
        var scene = decodeURIComponent(options.scene);
        if (user_id != undefined) {
            parent_id = user_id;
        }
        else if (scene != undefined) {
            parent_id = scene;
        }
        app.loginBindParent({parent_id: parent_id});
    },

    /**
     * 加载页面数据
     */
    loadData: function (options) {
        var page = this;
        app.request({
            url: api.default.index,
            success: function (res) {
                if (res.code == 0) {
                    page.setData(res.data);
                    /*
                    page.setData({
                        banner_list: res.data.banner_list,
                        nav_icon_list: res.data.nav_icon_list,
                        cat_list: res.data.cat_list,
                    });
                    */
                }
            },
            complete: function () {
                wx.stopPullDownRefresh();
            }
        });

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        share_count = 0;
        var store = wx.getStorageSync("store");
        if (store && store.name) {
            wx.setNavigationBarTitle({
                title: store.name,
            });
        }
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        this.loadData();
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (options) {
        var page = this;
        var user_info = wx.getStorageSync("user_info");
        return {
            path: "/pages/index/index?user_id=" + user_info.id,
            success: function (e) {
                share_count++;
                if (share_count == 1)
                    app.shareSendCoupon(page);
            }
        };
    },


});
