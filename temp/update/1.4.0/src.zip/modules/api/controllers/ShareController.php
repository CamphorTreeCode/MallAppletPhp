<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/8
 * Time: 14:15
 */

namespace app\modules\api\controllers;

use app\extensions\CreateQrcode;
use app\models\Color;
use app\models\Qrcode;
use app\models\Setting;
use app\models\Share;
use app\models\User;
use app\modules\api\behaviors\LoginBehavior;
use app\modules\api\models\BindForm;
use app\modules\api\models\CashForm;
use app\modules\api\models\CashListForm;
use app\modules\api\models\QrcodeForm;
use app\modules\api\models\ShareForm;
use app\modules\api\models\TeamForm;
use yii\helpers\VarDumper;

class ShareController extends Controller
{

    public function behaviors()
    {
        return array_merge(parent::behaviors(), [
            'login' => [
                'class' => LoginBehavior::className(),
            ],
        ]);
    }

    /**
     * @return mixed|string
     * 申请成为分销商
     */
    public function actionJoin()
    {
        $share = Share::findOne(['user_id' => \Yii::$app->user->identity->id, 'store_id' => $this->store->id, 'is_delete' => 0]);
        if (!$share) {
            $share = new Share();
        }
        $share_setting = Setting::findOne(['store_id'=>$this->store_id]);
        $form = new ShareForm();
        $form->share = $share;
        $form->store_id = $this->store_id;
        $form->attributes = \Yii::$app->request->post();
        if($share_setting->share_condition == 1){
            $form->scenario = "APPLY";
        }else if($share_setting->share_condition == 0){
            $form->agree = 1;
        }
        return json_encode($form->save(), JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 获取用户的审核状态
     */
    public function actionCheck()
    {
        $setting = Setting::findOne(['store_id' => $this->store_id]);
        if ($setting->share_condition == 0) {
            $share = Share::findOne(['user_id' => \Yii::$app->user->identity->id, 'store_id' => $this->store->id, 'is_delete' => 0]);
            if (!$share) {
                $share = new Share();
            }
            $form = new ShareForm();
            $form->share = $share;
            $form->store_id = $this->store_id;
//            $form->scenario = "NONE_CONDITION";
            $form->attributes = \Yii::$app->request->post();
            $res = $form->save();
            if ($res['code'] == 0) {
                return json_encode([
                    'code' => 0,
                    'msg' => 'success',
                    'data' => 2,
                    'level' => $setting->level
                ], JSON_UNESCAPED_UNICODE);
            }
        } else {
            return json_encode([
                'code' => 0,
                'msg' => 'success',
                'data' => \Yii::$app->user->identity->is_distributor,
                'level' => $setting->level
            ], JSON_UNESCAPED_UNICODE);
        }
    }

    /**
     * @return mixed|string
     * 获取分销中心数据
     */
    public function actionGetInfo()
    {
        $res = [
            'code' => 0,
            'msg' => 'success',
        ];
        //获取分销佣金及提现
        $form = new ShareForm();
        $form->store_id = $this->store_id;
        $form->user_id = \Yii::$app->user->identity->id;
        $res['data']['price'] = $form->getPrice();
        //获取我的团队
        $team = new TeamForm();
        $team->user_id = \Yii::$app->user->id;
        $team->store_id = $this->store_id;
        $team->status = -1;
        $get_team = $team->getList();
        $res['data']['team_count'] = $get_team['data']['first']+$get_team['data']['second']+$get_team['data']['third'];
        //获取分销订单总额
        $order = $team->GetOrder();
        $money = 0;
        foreach($order['data'] as $index=>$value){
            $money += $value['share_money'];
        }
        $res['data']['order_money'] = $money;

        return json_encode($res, JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 获取佣金相关
     */
    public function actionGetPrice()
    {
        $form = new ShareForm();
        $form->store_id = $this->store_id;
        $form->user_id = \Yii::$app->user->identity->id;
        $res['data']['price'] = $form->getPrice();
        return $this->renderJson($res);
    }

    /**
     * @return mixed|string
     * 申请提现
     */
    public function actionApply()
    {
        $form = new CashForm();
        $form->user_id = \Yii::$app->user->identity->id;
        $form->store_id = $this->store_id;
        $form->attributes = \Yii::$app->request->post();
        return json_encode($form->save(), JSON_UNESCAPED_UNICODE);
    }

    /**
     * 提现明细列表
     */
    public function actionCashDetail()
    {
        $form = new CashListForm();
        $form->attributes = \Yii::$app->request->get();
        $form->store_id = $this->store->id;
        $form->user_id = \Yii::$app->user->id;
        $this->renderJson($form->getList());
    }

    /**
     * @return mixed|string
     * 获取推广海报
     */
    public function actionGetQrcode()
    {
        //获取用户信息
        $user_id = \Yii::$app->user->id;
        $store_id = $this->store_id;
        $user = User::findOne(['id'=>$user_id,'store_id'=>$store_id]);
        $avatar = $user->avatar_url;
        $name = $user->nickname;

        //获取商户海报设置  默认为1
        $store_qrcode = Qrcode::findOne(['store_id'=>$store_id,'is_delete'=>0]);
        if(!$store_qrcode){
            $store_qrcode = Qrcode::findOne(1);
        }
        $font_position = json_decode($store_qrcode->font_position,true);
        $qrcode_position = json_decode($store_qrcode->qrcode_position,true);
        $avatar_position = json_decode($store_qrcode->avatar_position,true);
        $avatar_size = json_decode($store_qrcode->avatar_size,true);
        $qrcode_size = json_decode($store_qrcode->qrcode_size,true);
        $font_size = json_decode($store_qrcode->font,true);
        list($qrcode_bg_w, $qrcode_bg_h) = getimagesize($store_qrcode->qrcode_bg);

        //获取微信小程序码
        $access_token = $this->wechat->getAccessToken();
        $api = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token={$access_token}";
        $data = json_encode([
            'scene'=>"{$user_id}",
//            'page'=>"pages/index/index",
            'width'=>(int)$qrcode_size['w']/300*$qrcode_bg_w
        ],JSON_UNESCAPED_UNICODE);
        $this->wechat->curl->post($api,$data);
        $res = $this->wechat->curl->response;

        //保存到本地
        $saveRoot = \Yii::$app->basePath . '/web/';
        $saveDir = 'qrcode/';
        if (!is_dir($saveRoot . $saveDir)) {
            mkdir($saveRoot . $saveDir);
            file_put_contents($saveRoot . $saveDir . '.gitignore', "*\r\n!.gitignore");
        }
        $webRoot = \Yii::$app->request->baseUrl . '/';
        $saveName = md5(uniqid()) . '.png';
        file_put_contents($saveRoot.$saveDir.$saveName,$res);
//        $qrcode = $webRoot.$saveDir.$saveName;


//        $qrcode_bg = \Yii::$app->basePath.'/web/qrcode/2.png';
//        $form = new QrcodeForm();
//        $form->qrcode = $saveRoot.$saveDir.$saveName;
//        $form->avatar = $avatar;
//        $form->name = $name;
//        $form->qrcode_bg = $qrcode_bg;
        $form = new CreateQrcode();
        $form->qrcode = $saveRoot.$saveDir.$saveName;
        $form->avatar = $avatar;
        $form->name = $name;
        $form->store_qrcode = $store_qrcode;
        $form->font_x = (int)$font_position['x']/300*$qrcode_bg_w;
        $form->font_y = (int)$font_position['y']/300*$qrcode_bg_w+(int)$font_size['size']/5*12;
        $color = Color::find()->andWhere(['id'=>(int)$font_size['color']])->asArray()->one();
        $form->font_size = (int)$font_size['size']*1.5;
        $form->font_color = json_decode($color['rgb'],true);

        $form->qrcode_x = (int)$qrcode_position['x']/300*$qrcode_bg_w;
        $form->qrcode_w = (int)$qrcode_size['w']/300*$qrcode_bg_w;
        $form->qrcode_y = (int)$qrcode_position['y']/300*$qrcode_bg_w;
        $form->qrcode_true = isset($qrcode_size['c'])?$qrcode_size['c']:true;

        $form->avatar_x = (int)$avatar_position['x']/300*$qrcode_bg_w;
        $form->avatar_y = (int)$avatar_position['y']/300*$qrcode_bg_w;
        $form->avatar_w = (int)$avatar_size['w']/300*$qrcode_bg_w;
        $form->avatar_h = (int)$avatar_size['h']/300*$qrcode_bg_w;

        $form->qrcode_bg = $store_qrcode->qrcode_bg;
        return json_encode($form->getQrcode(), JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 商店分销设置信息
     */
    public function actionShopShare()
    {
        $list = Setting::find()->alias('s')
            ->where(['s.store_id'=>$this->store_id])
            ->leftJoin('{{%qrcode}} q','q.store_id=s.store_id and q.is_delete=0')
            ->select(['s.level','q.qrcode_bg'])
            ->asArray()->one();
        return json_encode([
            'code'=>0,
            'msg'=>'',
            'data'=>$list
        ],JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 绑定上下级关系
     */
    public function actionBindParent()
    {
        $form = new BindForm();
        $form->user_id = \Yii::$app->user->id;
        $form->store_id = $this->store_id;
        return json_encode($form->save(),JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 获取团队详情
     */
    public function actionGetTeam()
    {
        $form = new TeamForm();
        $form->user_id = \Yii::$app->user->id;
        $form->store_id = $this->store_id;
        $form->scenario = "TEAM";
        $form->attributes = \Yii::$app->request->get();
        return json_encode($form->getList(),JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return mixed|string
     * 获取分销订单
     */
    public function actionGetOrder()
    {
        $form = new TeamForm();
        $form->user_id = \Yii::$app->user->id;
        $form->store_id = $this->store_id;
        $form->scenario = "ORDER";
        $form->attributes = \Yii::$app->request->get();
        return json_encode($form->getOrder(),JSON_UNESCAPED_UNICODE);
    }
}