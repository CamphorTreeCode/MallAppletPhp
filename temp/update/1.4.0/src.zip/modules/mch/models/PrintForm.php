<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/31
 * Time: 15:22
 */

namespace app\modules\mch\models;
use app\extensions\KdOrder;
use app\models\Express;
use app\models\Order;

class PrintForm extends Model
{
    public $order_id;
    public $store_id;

    public function send()
    {
        $order = Order::findOne(['id'=>$this->order_id]);
        $express = Express::findOne(['name'=>$order->express]);
//构造电子面单提交信息
        $eorder = [];
        $eorder["ShipperCode"] = $express->code;
        $eorder["OrderCode"] = $order->order_no;
        $eorder["PayType"] = 1;
        $eorder["ExpType"] = 1;
        $eorder["IsReturnPrintTemplate"] = 1;

        $sender = [];
        $sender["Name"] = "李先生";
        $sender["Mobile"] = "18888888888";
        $sender["ProvinceName"] = "李先生";
        $sender["CityName"] = "深圳市";
        $sender["ExpAreaName"] = "福田区";
        $sender["Address"] = "赛格广场5401AB";

        $receiver = [];
        $receiver["Name"] = "李先生";
        $receiver["Mobile"] = "18888888888";
        $receiver["ProvinceName"] = "广东省";
        $receiver["CityName"] = "深圳市";
        $receiver["ExpAreaName"] = "福田区";
        $receiver["Address"] = "赛格广场5401AB";

        $commodityOne = [];
        $commodityOne["GoodsName"] = "其他";
        $commodityOne["Goodsquantity"] = $order;
        $commodity = [];
        $commodity[] = $commodityOne;

        $eorder["Sender"] = $sender;
        $eorder["Receiver"] = $receiver;
        $eorder["Commodity"] = $commodity;


//调用电子面单
        $jsonParam = json_encode($eorder, JSON_UNESCAPED_UNICODE);

//$jsonParam = JSON($eorder);//兼容php5.2（含）以下

//        echo "电子面单接口提交内容：<br/>".$jsonParam;
        $jsonResult = KdOrder::submitEOrder($jsonParam,$this->store_id);
//        echo "<br/><br/>电子面单提交结果:<br/>".$jsonResult;

//解析电子面单返回结果
        $result = json_decode($jsonResult, true);
//        echo "<br/><br/>返回码:".$result["ResultCode"];
        if($result["ResultCode"] == "100") {
//            echo "<br/>是否成功:".$result["Success"];
            return [
                'code'=>0,
                'msg'=>'成功',
                'data'=>$result['PrintTemplate']
            ];
        }
        else {
//            echo "<br/>电子面单下单失败";
            return [
                'code'=>1,
                'msg'=>$result['Reason']
            ];
        }
    }
}