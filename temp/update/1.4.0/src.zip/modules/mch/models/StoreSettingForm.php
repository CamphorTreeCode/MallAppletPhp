<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/6/26
 * Time: 14:38
 */

namespace app\modules\mch\models;


use app\models\Store;
use app\models\WechatApp;

class StoreSettingForm extends Model
{
    public $store_id;
    public $name;
    public $order_send_tpl;

    public $app_id;
    public $app_secret;
    public $mch_id;
    public $key;
    public $cert_pem;
    public $key_pem;

    public $contact_tel;
    public $show_customer_service;
    public $copyright;
    public $copyright_pic_url;
    public $copyright_url;

    public $delivery_time;
    public $after_sale_time;

    public $kdniao_mch_id;
    public $kdniao_api_key;

    public $cat_style;

    public function rules()
    {
        return [
            [['name', 'app_id', 'app_secret', 'mch_id', 'key', 'order_send_tpl', 'contact_tel', 'copyright', 'copyright_pic_url', 'copyright_url', 'kdniao_mch_id', 'kdniao_api_key',], 'trim'],
            [['name', 'app_id', 'app_secret', 'mch_id', 'key', 'cert_pem', 'key_pem',], 'required'],
            [['order_send_tpl', 'contact_tel', 'kdniao_mch_id', 'kdniao_api_key',], 'string'],
            [['show_customer_service', 'delivery_time', 'after_sale_time', 'cat_style',], 'integer'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'name' => '店铺名称',
            'app_id' => '小程序AppId',
            'app_secret' => '小程序AppSecret',
            'mch_id' => '微信支付商户号',
            'key' => '微信支付key',
            'cert_pem' => '微信支付apiclient_cert.pem',
            'key_pem' => '微信支付apiclient_key.pem',

            'order_send_tpl' => '发货模板消息id',
            'delivery_time' => '收货时间',
            'after_sale_time' => '售后时间'
        ];
    }

    public function save()
    {
        if (!$this->validate())
            return $this->getModelError();
        $store = Store::findOne($this->store_id);
        $store->name = $this->name;
        $store->order_send_tpl = $this->order_send_tpl;
        $store->contact_tel = $this->contact_tel;
        $store->show_customer_service = $this->show_customer_service;
        $store->copyright = $this->copyright;
        $store->copyright_pic_url = $this->copyright_pic_url;
        $store->copyright_url = $this->copyright_url;
        $store->delivery_time = $this->delivery_time;
        $store->after_sale_time = $this->after_sale_time;
        $store->kdniao_mch_id = $this->kdniao_mch_id;
        $store->kdniao_api_key = $this->kdniao_api_key;
        $store->cat_style = $this->cat_style;
        $store->save();

        $wechat_app = WechatApp::findOne($store->wechat_app_id);
        $wechat_app->app_id = $this->app_id;
        $wechat_app->app_secret = $this->app_secret;
        $wechat_app->mch_id = $this->mch_id;
        $wechat_app->key = $this->key;
        $wechat_app->cert_pem = $this->cert_pem;
        $wechat_app->key_pem = $this->key_pem;
        $wechat_app->save();

        return [
            'code' => 0,
            'msg' => '保存成功',
            'attr' => $store->attributes
        ];
    }
}