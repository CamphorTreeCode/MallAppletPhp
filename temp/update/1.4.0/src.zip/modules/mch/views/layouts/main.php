<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/6/19
 * Time: 16:52
 * @var \yii\web\View $this
 */
$urlManager = Yii::$app->urlManager;
$this->params['active_nav_group'] = isset($this->params['active_nav_group']) ? $this->params['active_nav_group'] : 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <title><?= $this->title ?></title>
    <link href="//at.alicdn.com/t/font_4mlfh2ebvshbbj4i.css" rel="stylesheet">
    <link href="//cdn.bootcss.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= Yii::$app->request->baseUrl ?>/statics/css/common.css" rel="stylesheet">
    <link href="<?= Yii::$app->request->baseUrl ?>/statics/css/flex.css" rel="stylesheet">


    <link href="<?= Yii::$app->request->baseUrl ?>/statics/mch/css/common.css" rel="stylesheet">
    <style>

    </style>
    <script>
        var _csrf = "<?=Yii::$app->request->csrfToken?>";
    </script>
    <script src="//cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/vue/2.3.4/vue.js"></script>
    <script src="//cdn.bootcss.com/tether/1.4.0/js/tether.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
    <script src="//cdn.bootcss.com/plupload/2.3.0/plupload.full.min.js"></script>
    <script src="<?= Yii::$app->request->baseUrl ?>/statics/js/common.js"></script>


</head>
<body>
<div class="sidebar">
    <div class="sidebar-nav">
        <div class="sidebar-logo" style="padding: 1.5rem 2rem;">
            <div style="font-size: 1.2rem;margin-bottom: .5rem">
                <a style="color: #fff;"
                   href="<?= $urlManager->createUrl(['mch/store']) ?>"><?= $this->context->store->name ?></a>
            </div>
            <div style="font-size: .85rem;color: #bbb;display: none">
                <a href="http://cloud.zjhejiang.com/we7/mall/" target="_blank">禾匠商城</a>
                <span>v<?= $this->context->version ?></span>
            </div>
        </div>
        <div class="nav-group <?= $this->params['active_nav_group'] == 1 ? 'active' : null ?>">
            <a href="javascript:"><span class="mr-2">◈</span>商城管理</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/store/setting']) ?>"><span class="mr-2">●</span>商城设置</a>
                <a href="<?= $urlManager->createUrl(['mch/store/home-page']) ?>"><span class="mr-2">●</span>首页设置</a>
                <a href="<?= $urlManager->createUrl(['mch/store/home-block']) ?>"><span class="mr-2">●</span>首页板块</a>
                <a href="<?= $urlManager->createUrl(['mch/store/sms']) ?>"><span class="mr-2">●</span>短信设置</a>
                <a href="<?= $urlManager->createUrl(['mch/store/slide']) ?>"><span class="mr-2">●</span>轮播图</a>
                <a href="<?= $urlManager->createUrl(['mch/store/home-nav']) ?>"><span class="mr-2">●</span>导航图标</a>
                <a href="<?= $urlManager->createUrl(['mch/store/postage-rules']) ?>"><span class="mr-2">●</span>运费规则</a>
                <a href="<?= $urlManager->createUrl(['mch/store/wxapp']) ?>"><span class="mr-2">●</span>小程序发布</a>
                <?php if ($this->context->is_admin): ?>
                    <a href="<?= $urlManager->createUrl(['mch/update/index']) ?>"><span class="mr-2">●</span>系统更新</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="nav-group <?= $this->params['active_nav_group'] == 2 ? 'active' : null ?>">
            <a href="javascript:"><span class="mr-2">◈</span>商品管理</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/store/cat']) ?>"><span class="mr-2">●</span>商品分类</a>
                <a href="<?= $urlManager->createUrl(['mch/store/attr']) ?>"><span class="mr-2">●</span>商品规格</a>
                <a href="<?= $urlManager->createUrl(['mch/goods/goods']) ?>"><span class="mr-2">◈</span>商品列表</a>
            </div>
        </div>

        <div class="nav-group <?= $this->params['active_nav_group'] == 7 ? 'active' : null ?>">
            <a href="javascript:"><span class="mr-2">◈</span>优惠券管理</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/coupon/index']) ?>"><span class="mr-2">●</span>优惠券列表</a>
                <a href="<?= $urlManager->createUrl(['mch/coupon/auto-send']) ?>"><span class="mr-2">●</span>优惠券自动发放</a>
            </div>
        </div>

        <div class="nav-group <?= $this->params['active_nav_group'] == 3 ? 'active' : null ?>">
            <a href="javascript:"><span class="mr-2">◈</span>订单管理</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/order/index']) ?>"><span class="mr-2">●</span>订单列表</a>
                <a href="<?= $urlManager->createUrl(['mch/order/refund']) ?>"><span class="mr-2">●</span>售后订单</a>
                <a href="<?= $urlManager->createUrl(['mch/comment/index']) ?>"><span class="mr-2">●</span>评价管理</a>
            </div>
        </div>
        <div class="nav-group <?= $this->params['active_nav_group'] == 4 ? 'active' : null ?>">
            <a href="<?= $urlManager->createUrl(['mch/user/index']) ?>"><span class="mr-2">◈</span>用户管理</a>
        </div>
        <div class="nav-group <?= $this->params['active_nav_group'] == 5 ? 'active' : null ?>">
            <a href="JavaScript:"><span class="mr-2">◈</span>分销商管理</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/share/index']) ?>"><span class="mr-2">●</span>分销商列表</a>
                <a href="<?= $urlManager->createUrl(['mch/share/cash']) ?>"><span class="mr-2">●</span>提现列表</a>
                <a href="<?= $urlManager->createUrl(['mch/share/setting']) ?>"><span class="mr-2">●</span>佣金设置</a>
                <a href="<?= $urlManager->createUrl(['mch/share/basic']) ?>"><span class="mr-2">●</span>基础设置</a>
            </div>
        </div>
        <div class="nav-group <?= $this->params['active_nav_group'] == 6 ? 'active' : null ?>">
            <a href="JavaScript:"><span class="mr-2">◈</span>系统文章</a>
            <div class="sub-nav-list">
                <a href="<?= $urlManager->createUrl(['mch/article/index', 'cat_id' => '1']) ?>"><span
                            class="mr-2">●</span>关于我们</a>
                <a href="<?= $urlManager->createUrl(['mch/article/index', 'cat_id' => '2']) ?>"><span
                            class="mr-2">●</span>服务中心</a>
            </div>
        </div>
    </div>
</div>
<div class="main">
    <?= $content ?>
</div>
<script>
    $(document).on("click", ".sidebar-nav .nav-group > a", function () {
        var group = $(this).parents(".nav-group");
        if (group.hasClass("active")) {
            group.removeClass("active");
        } else {
            $(this).parents(".nav-group").addClass("active").siblings().removeClass("active");
        }
    });

    $(document).on("click", ".input-hide .tip-block", function () {
        $(this).hide();
    });


    $(document).on("click", ".input-group .dropdown-item", function () {
        var val = $.trim($(this).text());
        $(this).parents(".input-group").find(".form-control").val(val);
    });
</script>
</body>
</html>