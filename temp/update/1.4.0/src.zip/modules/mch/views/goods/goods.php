<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/29
 * Time: 9:50
 */
use yii\widgets\LinkPager;

$urlManager = Yii::$app->urlManager;
$this->title = '商品列表';
$this->params['active_nav_group'] = 2;
?>
<style>
    table {
        table-layout: fixed;
    }

    th {
        text-align: center;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }

    td {
        text-align: center;
    }

    .ellipsis {
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }

    td.nowrap {
        white-space: nowrap;
        overflow: hidden;
    }

    .goods-pic {
        width: 3rem;
        height: 3rem;
        display: inline-block;
        background-color: #ddd;
        background-size: cover;
        background-position: center;
    }
</style>

<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>


<div class="main-body p-3">

    <?php
    $status = ['已下架', '已上架'];
    ?>
    <div class="mb-3 clearfix">
        <a href="<?= $urlManager->createAbsoluteUrl(['mch/goods/goods-edit']) ?>" class="btn btn-primary"><i
                    class="iconfont icon-playlistadd"></i>添加商品</a>
        <div class="float-right">
            <form method="get">

                <?php $_s = ['keyword'] ?>
                <?php foreach ($_GET as $_gi => $_gv):if (in_array($_gi, $_s)) continue; ?>
                    <input type="hidden" name="<?= $_gi ?>" value="<?= $_gv ?>">
                <?php endforeach; ?>

                <div class="input-group">
                    <input class="form-control" placeholder="商品名/商品类型" name="keyword"
                           value="<?= isset($_GET['keyword']) ? trim($_GET['keyword']) : null ?>">
                    <span class="input-group-btn">
                    <button class="btn btn-primary">搜索</button>
                </span>
                </div>
            </form>
        </div>
    </div>
    <table class="table table-bordered bg-white">
        <thead>
        <tr>
            <th>ID</th>
            <th>商品类型</th>
            <th class="text-left">商品名称</th>
            <th hidden>商品图片</th>
            <th>售价</th>
            <th>库存</th>
            <th>状态</th>
            <!--<th>排序</th>-->
            <th>操作</th>
        </tr>
        </thead>
        <col style="width: 10%">
        <col style="width: 10%">
        <col style="width: 40%">
        <col style="width: 10%">
        <col style="width: 5%">
        <col style="width: 10%">
        <col style="width: 10%">
        <tbody>
        <?php foreach ($list as $index => $goods): ?>
            <tr>
                <td class="nowrap"><?= $goods->id ?></td>
                <td class="nowrap"><?= $goods->cat->name ?></td>
                <td class="text-left ellipsis"><?= $goods->name ?></td>
                <td hidden class="p-0" style="vertical-align: middle">
                    <div class="goods-pic" style="background-image: url(<?= $goods->getGoodsPic(0)->pic_url ?>)"></div>
                </td>
                <td class="nowrap text-danger"><?= $goods->price ?></td>
                <td class="nowrap">
                    <a href="<?= $urlManager->createUrl(['mch/goods/goods-attr', 'id' => $goods->id]) ?>"><?= $goods->num ?></a>
                </td>
                <td class="nowrap">
                    <?php if ($goods->status == 1): ?>
                        <span class="badge badge-success"><?= $status[$goods->status] ?></span>
                        |
                        <a href="javascript:" onclick="upDown(<?= $goods->id ?>,'down');">下架</a>
                    <?php else: ?>
                        <span class="badge badge-default"><?= $status[$goods->status] ?></span>
                        |
                        <a href="javascript:" onclick="upDown(<?= $goods->id ?>,'up');">上架</a>
                    <?php endif ?>
                </td>
                <!--
                <td class="nowrap">
                    <?=$goods->sort?>
                </td>
                -->
                <td class="nowrap">
                    <a class="btn btn-sm btn-primary"
                       href="<?= $urlManager->createAbsoluteUrl(['mch/goods/goods-edit', 'id' => $goods->id]) ?>">修改</a>
                    <a class="btn btn-sm btn-danger del"
                       href="<?= $urlManager->createAbsoluteUrl(['mch/goods/goods-del', 'id' => $goods->id]) ?>">删除</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>

    </table>
    <nav aria-label="Page navigation example">
        <?php echo LinkPager::widget([
            'pagination' => $pagination,
            'prevPageLabel' => '上一页',
            'nextPageLabel' => '下一页',
            'firstPageLabel' => '首页',
            'lastPageLabel' => '尾页',
            'maxButtonCount' => 5,
            'options' => [
                'class' => 'pagination',
            ],
            'prevPageCssClass' => 'page-item',
            'pageCssClass' => "page-item",
            'nextPageCssClass' => 'page-item',
            'firstPageCssClass' => 'page-item',
            'lastPageCssClass' => 'page-item',
            'linkOptions' => [
                'class' => 'page-link',
            ],
            'disabledListItemSubTagOptions' => ['tag' => 'a', 'class' => 'page-link'],
        ])
        ?>
    </nav>
</div>
<script>
    $(document).on('click', '.del', function () {
        if (confirm("是否删除？")) {
            $.ajax({
                url: $(this).attr('href'),
                type: 'get',
                dataType: 'json',
                success: function (res) {
                    alert(res.msg);
                    if (res.code == 0) {
                        window.location.reload();
                    }
                }
            });
        }
        return false;
    });

    function upDown(id, type) {
        var text = '';
        if (type == 'up') {
            text = "上架";
        } else {
            text = '下架';
        }

        var url = "<?= $urlManager->createAbsoluteUrl(['mch/goods/goods-up-down']) ?>";
        if (confirm("是否" + text + "？")) {
            $.ajax({
                url: url,
                type: 'get',
                dataType: 'json',
                data: {id: id, type: type},
                success: function (res) {
                    if (res.code == 0) {
                        window.location.reload();
                    }
                    if (res.code == 1) {
                        alert(res.msg);
                        if (res.return_url) {
                            location.href = res.return_url;
                        }
                    }
                }
            });
        }
        return false;
    }
</script>