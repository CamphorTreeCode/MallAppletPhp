<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/31
 * Time: 18:05
 */
?>
<div style="text-align: center;position: relative">
    <div style="position: absolute;left: 0;top: 0;width: 100%;height: 100%;background: rgba(255,255,255,.75);z-index:1;padding: 6px">
        <div>搜索框</div>
    </div>
    <img src="<?= Yii::$app->request->baseUrl ?>/statics/images/search-bg.png" style="width: 100%;height: auto">
</div>