<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/6/19
 * Time: 16:43
 */

namespace app\modules\mch\controllers;


use app\extensions\Sms;
use app\models\Attr;
use app\models\AttrGroup;
use app\models\Banner;
use app\models\Cat;
use app\models\District;
use app\models\Express;
use app\models\HomeBlock;
use app\models\HomeNav;
use app\models\HomePageModule;
use app\models\PostageRules;
use app\models\SmsSetting;
use app\modules\mch\models\AttrAddForm;
use app\modules\mch\models\AttrDeleteForm;
use app\modules\mch\models\AttrUpdateForm;
use app\modules\mch\models\BannerForm;
use app\modules\mch\models\CatForm;
use app\modules\mch\models\HomeBlockEditForm;
use app\modules\mch\models\HomeNavEditForm;
use app\modules\mch\models\PostageRulesEditForm;
use app\modules\mch\models\SmsForm;
use app\modules\mch\models\StoreDataForm;
use app\modules\mch\models\StoreSettingForm;
use Comodojo\Zip\Zip;
use League\Flysystem\Filesystem;
use League\Flysystem\ZipArchive\ZipArchiveAdapter;
use yii\helpers\VarDumper;

class StoreController extends Controller
{
    public function actionIndex()
    {
        $form = new StoreDataForm();
        $form->store_id = $this->store->id;
        $store_data = $form->search();
        return $this->render('index', [
            'store' => $this->store,
            'store_data' => $store_data,
        ]);
    }

    /**
     * 基本信息
     */
    public function actionSetting()
    {
        if (\Yii::$app->request->isPost) {
            $form = new StoreSettingForm();
            $form->attributes = \Yii::$app->request->post();
            $form->store_id = $this->store->id;
            $this->renderJson($form->save());
        } else {
            return $this->render('setting', [
                'store' => $this->store,
                'wechat_app' => $this->wechat_app,
            ]);
        }
    }

    /**
     * 首页幻灯片
     */
    public function actionSlide()
    {
        $store = $this->store->id;
        $form = new BannerForm();
        $arr = $form->getList($store);
        return $this->render('slide', [
            'list' => $arr[0],
            'pagination' => $arr[1],
        ]);
    }

    /**
     * 幻灯片添加修改
     */
    public function actionSlideEdit($id = 0)
    {
        $banner = Banner::findOne(['id' => $id]);
        if (!$banner) {
            $banner = new Banner();
        }
        $form = new BannerForm();
        if (\Yii::$app->request->isPost) {
            $model = \Yii::$app->request->post('model');
            $model['store_id'] = $this->store->id;
            $form->attributes = $model;
            $form->banner = $banner;
            return json_encode($form->save(), JSON_UNESCAPED_UNICODE);
        }
        return $this->render('slide-edit', [
            'list' => $banner
        ]);
    }

    /**
     * 幻灯片删除
     * @param int $id
     */
    public function actionSlideDel($id = 0)
    {
        $dishes = Banner::findOne(['id' => $id, 'is_delete' => 0]);
        if (!$dishes) {
            $this->renderJson([
                'code' => 1,
                'msg' => '幻灯片不存在或已经删除'
            ]);
        }
        $dishes->is_delete = 1;
        if ($dishes->save()) {
            $this->renderJson([
                'code' => 0,
                'msg' => '成功'
            ]);
        } else {
            foreach ($dishes->errors as $errors) {
                $this->renderJson([
                    'code' => 1,
                    'msg' => $errors[0],
                ]);
            }
        }
    }

    /**
     * 分类列表
     */
    public function actionCat()
    {
        $cat_list = Cat::find()->where(['store_id' => $this->store->id, 'is_delete' => 0, 'parent_id' => 0])->orderBy('sort,addtime DESC')->all();
        return $this->render('cat', [
            'cat_list' => $cat_list,
        ]);
    }

    /**
     * 分类编辑
     */
    public function actionCatEdit($id = null)
    {
        $cat = Cat::findOne(['id' => $id]);
        if (!$cat) {
            $cat = new Cat();
        }
        $form = new CatForm();
        if (\Yii::$app->request->isPost) {
            $model = \Yii::$app->request->post('model');
            $model['store_id'] = $this->store->id;
            $form->attributes = $model;
            $form->cat = $cat;
            return json_encode($form->save(), JSON_UNESCAPED_UNICODE);
        }
        return $this->render('cat-edit', [
            'parent_list' => Cat::findAll(['store_id' => $this->store->id, 'is_delete' => 0, 'parent_id' => 0]),
            'list' => $cat,
        ]);
    }

    /**
     * 分类删除
     */
    public function actionCatDel($id)
    {
        $dishes = Cat::findOne(['id' => $id, 'is_delete' => 0]);
        if (!$dishes) {
            $this->renderJson([
                'code' => 1,
                'msg' => '商品分类删除失败或已删除'
            ]);
        }
        $dishes->is_delete = 1;
        if ($dishes->save()) {
            $this->renderJson([
                'code' => 0,
                'msg' => '成功'
            ]);
        } else {
            foreach ($dishes->errors as $errors) {
                $this->renderJson([
                    'code' => 1,
                    'msg' => $errors[0],
                ]);
            }
        }
    }

    /**
     * 运费规则列表
     */
    public function actionPostageRules()
    {
        return $this->render('postage-rules', [
            'list' => PostageRules::findAll([
                'store_id' => $this->store->id,
                'is_delete' => 0,
            ]),
        ]);
    }

    /**
     * 新增、编辑运费规则
     */
    public function actionPostageRulesEdit($id = null)
    {
        $model = PostageRules::findOne([
            'id' => $id,
            'store_id' => $this->store->id,
            'is_delete' => 0,
        ]);
        if (!$model) {
            $model = new PostageRules();
            $model->store_id = $this->store->id;
        }
        if (\Yii::$app->request->isPost) {
            $form = new PostageRulesEditForm();
            $form->attributes = \Yii::$app->request->post();
            $form->postage_rules = $model;
            $this->renderJson($form->save());
        } else {
            return $this->render('postage-rules-edit', [
                'model' => $model,
                'express_list' => Express::findAll([
                    'is_delete' => 0,
                ]),
                'province_list' => District::findAll(['level' => 'province']),
            ]);
        }
    }

    /**
     * 删除运费规则
     */
    public function actionPostageRulesDelete($id)
    {
        $model = PostageRules::findOne([
            'id' => $id,
            'store_id' => $this->store->id,
            'is_delete' => 0,
        ]);
        if ($model) {
            $model->is_delete = 1;
            $model->save();
        }
        $this->renderJson([
            'code' => 0,
            'msg' => '删除成功',
        ]);
    }

    public function actionPostageRulesSetEnable($id, $type)
    {
        if ($type == 0) {
            PostageRules::updateAll(['is_enable' => 0], ['store_id' => $this->store->id, 'is_delete' => 0, 'id' => $id]);
        }
        if ($type == 1) {
            PostageRules::updateAll(['is_enable' => 0], ['store_id' => $this->store->id, 'is_delete' => 0]);
            PostageRules::updateAll(['is_enable' => 1], ['store_id' => $this->store->id, 'is_delete' => 0, 'id' => $id]);
        }
        $this->redirect(\Yii::$app->request->referrer)->send();
    }

    //规格列表
    public function actionAttr()
    {
        $attr_list = Attr::find()
            ->select('a.id,ag.attr_group_name,a.attr_name')
            ->alias('a')->leftJoin(['ag' => AttrGroup::tableName()], 'a.attr_group_id=ag.id')
            ->where(['ag.store_id' => $this->store->id, 'a.is_delete' => 0, 'ag.is_delete' => 0])
            ->orderBy('ag.id DESC,a.id DESC')
            ->asArray()->all();
        return $this->render('attr', [
            'attr_group_list' => AttrGroup::findAll(['is_delete' => 0, 'store_id' => $this->store->id]),
            'attr_list' => $attr_list,
        ]);
    }

    //添加规格
    public function actionAttrAdd()
    {
        if (\Yii::$app->request->isPost) {
            $form = new AttrAddForm();
            $form->attributes = \Yii::$app->request->post();
            $form->store_id = $this->store->id;
            $this->renderJson($form->save());
        }
    }

    //修改规格
    public function actionAttrUpdate()
    {
        if (\Yii::$app->request->isPost) {
            $form = new AttrUpdateForm();
            $form->attributes = \Yii::$app->request->post();
            $form->store_id = $this->store->id;
            $this->renderJson($form->save());
        }
    }

    //修改规格
    public function actionAttrDelete()
    {
        $form = new AttrDeleteForm();
        $form->attributes = \Yii::$app->request->get();
        $form->store_id = $this->store->id;
        $this->renderJson($form->save());
    }

    //小程序安装
    public function actionWxapp()
    {
        if (\Yii::$app->request->isPost) {
            $this->_wxapp_write_api_file();
            $download_url = $this->_wxapp_zip_dir();
            $this->renderJson([
                'code' => 0,
                'msg' => 'success',
                'data' => $download_url,
            ]);
        } else {
            return $this->render('wxapp');
        }
    }

    //获取小程序二维码
    public function actionWxappQrcode()
    {
        if (\Yii::$app->request->isPost) {
            $save_file = md5($this->wechat->appId . $this->wechat->appSecret) . '.png';
            $save_dir = \Yii::$app->basePath . '/web/temp/' . $save_file;
            $web_dir = \Yii::$app->request->hostInfo . \Yii::$app->request->baseUrl . '/temp/' . $save_file;
            if (file_exists($save_dir)) {
                $this->renderJson([
                    'code' => 0,
                    'msg' => 'success',
                    'data' => $web_dir,
                ]);
            }
            $access_token = $this->wechat->getAccessToken();
            $api = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token={$access_token}";
            $data = json_encode([
                'scene' => '0',
                'path' => '/pages/index/index',
                'width' => 480,
            ], JSON_UNESCAPED_UNICODE);
            $this->wechat->curl->post($api, $data);
            file_put_contents($save_dir, $this->wechat->curl->response);
            $this->renderJson([
                'code' => 0,
                'msg' => 'success',
                'data' => $web_dir,
            ]);
        } else {
            $this->renderJson([
                'code' => 1,
            ]);
        }
    }

    //1.设置api.js文件
    private function _wxapp_write_api_file()
    {
        $app_root = str_replace('\\', '/', \Yii::$app->basePath) . '/';
        $api_root = str_replace('http://', 'https://', \Yii::$app->request->hostInfo) . \Yii::$app->urlManager->scriptUrl . "?store_id={$this->store->id}&r=api/";
        $api_tpl_file = $app_root . 'wechatapp/api.tpl.js';
        $api_file_content = file_get_contents($api_tpl_file);
        $api_file_content = str_replace('{$_api_root}', $api_root, $api_file_content);
        $api_file = $app_root . 'wechatapp/api.js';
        file_put_contents($api_file, $api_file_content);
    }

    //2.zip打包目录
    private function _wxapp_zip_dir()
    {
        $app_root = str_replace('\\', '/', \Yii::$app->basePath) . '/';
        $wxapp_root = $app_root . 'wechatapp';
        $zip_name = 'wechatapp' . date('Ymd') . rand(1000, 9999) . '.zip';
        $zip = Zip::create($app_root . 'web/temp/' . $zip_name);
        $zip->add($wxapp_root);
        return \Yii::$app->request->hostInfo . \Yii::$app->request->baseUrl . '/temp/' . $zip_name;
    }


    //首页导航图标
    public function actionHomeNav()
    {
        $list = HomeNav::find()->where(['store_id' => $this->store->id, 'is_delete' => 0])->orderBy('sort ASC,addtime DESC')->all();
        return $this->render('home-nav', [
            'list' => $list,
        ]);
    }

    /**
     * 首页导航图标编辑
     */
    public function actionHomeNavEdit($id = null)
    {
        $model = HomeNav::findOne(['id' => $id, 'store_id' => $this->store->id]);
        if (!$model) {
            $model = new HomeNav();
        }
        if (\Yii::$app->request->isPost) {
            $form = new HomeNavEditForm();
            $form->attributes = \Yii::$app->request->post('model');
            $form->store_id = $this->store->id;
            $form->model = $model;
            $this->renderJson($form->save());
        }
        return $this->render('home-nav-edit', [
            'model' => $model,
        ]);
    }

    /**
     * 首页导航图标删除
     */
    public function actionHomeNavDel($id = null)
    {
        $model = HomeNav::findOne(['id' => $id, 'store_id' => $this->store->id]);
        if (!$model) {
            $this->renderJson([
                'code' => 1,
                'msg' => '导航图标不存在，或已删除',
            ]);
        }
        $model->is_delete = 1;
        $model->save();
        $this->renderJson([
            'code' => 0,
            'msg' => '删除成功',
        ]);
    }

    /**
     * @return string
     * 短信模板设置
     */
    public function actionSms()
    {
        $form = new SmsForm();
        $list = SmsSetting::findOne(['store_id' => $this->store->id, 'is_delete' => 0]);
        if (!$list) {
            $list = new SmsSetting();
        }
        if (\Yii::$app->request->isPost) {
            $form->attributes = \Yii::$app->request->post();
            $form->store_id = $this->store->id;
            $form->sms = $list;
            $this->renderJson($form->save());
        }
        return $this->render('sms', [
            'sms' => $list
        ]);
    }

    //首页设置
    public function actionHomePage()
    {
        if (\Yii::$app->request->isPost) {
            $this->store->home_page_module = \Yii::$app->request->post('module_list');
            if ($this->store->save()) {
                $this->renderJson([
                    'code' => 0,
                    'msg' => '保存成功',
                ]);
            } else {
                $this->renderJson([
                    'code' => 1,
                    'msg' => '保存失败',
                ]);
            }
        } else {
            $form = new HomePageModule();
            $form->store_id = $this->store->id;
            return $this->render('home-page', [
                'module_list' => $form->search(),
                'edit_list' => $form->search(1),
            ]);
        }
    }

    //首页自定义板块
    public function actionHomeBlock()
    {
        $list = HomeBlock::find()->where(['store_id' => $this->store->id, 'is_delete' => 0])->orderBy('addtime DESC')->all();
        return $this->render('home-block', [
            'list' => $list,
        ]);
    }

    //首页自定义板块编辑
    public function actionHomeBlockEdit($id = null)
    {
        $model = HomeBlock::findOne([
            'id' => $id,
            'store_id' => $this->store->id,
            'is_delete' => 0,
        ]);
        if (!$model) {
            $model = new HomeBlock();
        }
        if (\Yii::$app->request->isPost) {
            $form = new HomeBlockEditForm();
            $form->attributes = \Yii::$app->request->post();
            $form->model = $model;
            $form->store = $this->store;
            return $this->renderJson($form->save());
        } else {
            return $this->render('home-block-edit', [
                'model' => $model,
            ]);
        }
    }


    //首页自定义板块删除
    public function actionHomeBlockDelete($id = null)
    {
        $model = HomeBlock::findOne([
            'id' => $id,
            'store_id' => $this->store->id,
            'is_delete' => 0,
        ]);
        if ($model) {
            $model->is_delete = 1;
            $model->save();
        }
        $this->renderJson([
            'code' => 0,
            'msg' => '删除成功',
        ]);
    }


}