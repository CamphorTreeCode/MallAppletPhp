<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/11
 * Time: 16:07
 */

namespace app\modules\api\models;


class QrcodeForm extends Model
{
    public $qrcode;
    public $qrcode_bg;
    public $avatar;
    public $name;


    public function getQrcode()
    {
        //创建图片的实例
        $qrcode_bg = imagecreatefromstring(file_get_contents($this->qrcode_bg));
        $qrcode = imagecreatefromstring(file_get_contents($this->qrcode));
        $avatar = imagecreatefromstring(file_get_contents($this->avatar));
        //获取水印图片的宽高
        list($qrcode_w, $qrcode_h) = getimagesize($this->qrcode);
        list($avatar_w, $avatar_h) = getimagesize($this->avatar);
        list($qrcode_bg_w, $qrcode_bg_h) = getimagesize($this->qrcode_bg);

        //压缩图片
        $new_width = 180;
        $new_height = 180;
        $image_thump = imagecreatetruecolor($new_width,$new_height);
        //将原图复制带图片载体上面，并且按照一定比例压缩,极大的保持了清晰度
        imagecopyresampled($image_thump,$avatar,0,0,0,0,$new_width,$new_height,$avatar_w,$avatar_h);
        imagedestroy($avatar);
        $avatar =   $image_thump;



        //将水印图片复制到目标图片上，最后个参数50是设置透明度，这里实现半透明效果
        imagecopymerge($qrcode_bg, $qrcode, ($qrcode_bg_w-$qrcode_w)/2, 526, 0, 0, $qrcode_w, $qrcode_h, 100);
        imagecopymerge($qrcode_bg, $avatar, 30, 290, 0, 0, 180, 180, 100);
        //如果水印图片本身带透明色，则使用imagecopy方法
        //imagecopy($dst, $src, 10, 10, 0, 0, $src_w, $src_h);

        $font = \Yii::$app->basePath.'/web/statics/font/AaBanSong.ttf';//字体
        $white = imagecolorallocate($qrcode_bg, 255, 255, 255);//字体颜色
        imagefttext($qrcode_bg, 36, 0, 254, 360, $white,$font, '我是：');
        $purple = imagecolorallocate($qrcode_bg, 100, 0, 224);//字体颜色
        imagefttext($qrcode_bg, 36, 0, 364, 360, $purple,$font, $this->name);
        imagefttext($qrcode_bg, 36, 0, 254, 420, $white,$font, '代言真的有钱赚！');
        imagefttext($qrcode_bg, 32, 0, 284, 1000, $white,$font, '扫描二维码');
        imagefttext($qrcode_bg, 32, 0, 264, 1050, $white,$font, '和我一起赚钱！');

        //输出图片
        list($qrcode_bg_w, $qrcode_bg_h, $qrcode_bg_type) = getimagesize($this->qrcode_bg);
//        switch ($qrcode_bg_type) {
//            case 1://GIF
//                header('Content-Type: image/gif');
//                imagegif($qrcode_bg);
//                break;
//            case 2://JPG
//                header('Content-Type: image/jpeg');
//                imagejpeg($qrcode_bg);
//                break;
//            case 3://PNG
//                header('Content-Type: image/png');
//                imagepng($qrcode_bg);
//                break;
//            default:
//                break;
//        }
        $saveRoot = \Yii::$app->basePath . '/web/';
        $saveDir = 'qrcode/';
        if (!is_dir($saveRoot . $saveDir)) {
            mkdir($saveRoot . $saveDir);
            file_put_contents($saveRoot . $saveDir . '.gitignore', "*\r\n!.gitignore");
        }
        $webRoot = \Yii::$app->request->baseUrl . '/';
        $saveName = md5(uniqid()) . '.png';
        imagepng($qrcode_bg,$saveRoot.$saveDir.$saveName);
//        file_put_contents($saveRoot.$saveDir.$saveName,$qrcode_bg);
        imagedestroy($qrcode_bg);
        imagedestroy($qrcode);
        imagedestroy($avatar);
        $qrcode = \Yii::$app->request->hostInfo.$webRoot.$saveDir.$saveName;
        return [
            'code'=>0,
            'msg'=>'success',
            'data'=>$qrcode
        ];
    }
}