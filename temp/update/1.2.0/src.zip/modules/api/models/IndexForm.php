<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/7/5
 * Time: 16:00
 */

namespace app\modules\api\models;


use app\models\Banner;
use app\models\Cat;
use app\models\Goods;
use app\models\GoodsPic;
use app\models\HomeNav;
use app\models\Store;

class IndexForm extends Model
{
    public $store_id;

    public function search()
    {
        $store = Store::findOne($this->store_id);
        if (!$store)
            return [
                'code' => 1,
                'msg' => 'Store不存在',
            ];

        $banner_list = Banner::find()->where([
            'is_delete' => 0,
            'store_id' => $this->store_id,
        ])->orderBy('sort ASC')->asArray()->all();
        foreach ($banner_list as $i => $banner) {
            $banner_list[$i]['open_type'] = 'navigate';
        }

        $nav_icon_list = HomeNav::find()->where([
            'is_delete' => 0,
            'store_id' => $this->store_id,
        ])->orderBy('sort ASC,addtime DESC')->select('name,pic_url,url,name,open_type')->asArray()->all();

        $cat_list = Cat::find()->where([
            'is_delete' => 0,
            'parent_id' => 0,
            'store_id' => $this->store_id,
        ])->orderBy('sort ASC')->asArray()->all();
        foreach ($cat_list as $i => $cat) {
            $cat_list[$i]['page_url'] = '/pages/list/list?cat_id=' . $cat['id'];
            $cat_list[$i]['open_type'] = 'navigate';
            $cat_list[$i]['cat_pic'] = $cat['pic_url'];
            $goods_list_form = new GoodsListForm();
            $goods_list_form->store_id = $this->store_id;
            $goods_list_form->cat_id = $cat['id'];
            $goods_list_form->limit = 6;
            $goods_list_form_res = $goods_list_form->search();
            $goods_list = $goods_list_form_res['code'] == 0 ? $goods_list_form_res['data']['list'] : [];
            $cat_list[$i]['goods_list'] = $goods_list;
        }
        return [
            'code' => 0,
            'msg' => 'success',
            'data' => [
                'store' => [
                    'id' => $store->id,
                    'name' => $store->name,
                ],
                'banner_list' => $banner_list,
                'nav_icon_list' => $nav_icon_list,
                'cat_list' => $cat_list,
            ],
        ];
    }
}