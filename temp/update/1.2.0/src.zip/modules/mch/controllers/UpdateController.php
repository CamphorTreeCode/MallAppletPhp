<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/3
 * Time: 14:36
 */

namespace app\modules\mch\controllers;


use Comodojo\Zip\Zip;

class UpdateController extends Controller
{
    public function actionIndex()
    {
        $version_list = json_decode(file_get_contents('http://cloud.zjhejiang.com/we7/mall/version.json'));
        rsort($version_list);
        return $this->render('index', [
            'version' => $this->version,
            'next_version' => $this->getNextVersion($this->version),
            'version_list' => $version_list,
        ]);
    }

    private function getNextVersion($current_version)
    {
        $remote_version = json_decode(file_get_contents('http://cloud.zjhejiang.com/we7/mall/version.json'));
        $mark = false;
        $next_version = null;
        foreach ($remote_version as $i => $v) {
            if ($mark && $v->tag == 'stable') {
                $next_version = $v;
                break;
            }
            if ($v->version == $current_version && $v->tag == 'stable') {
                $mark = true;
            }
        }
        return $next_version;
    }

    public function actionUpdate()
    {
        if (\Yii::$app->request->isPost) {
            $target_version = \Yii::$app->request->post('target_version');
            if (!$target_version)
                $this->renderJson([
                    'code' => 1,
                    'msg' => '版本不能为空',
                ]);
            $next_version = $this->getNextVersion($this->version);
            if (!$next_version)
                $this->renderJson([
                    'code' => 1,
                    'msg' => '版本v' . $target_version . '不存在，请刷新页面再重试',
                ]);
            if ($next_version->version != $target_version)
                $this->renderJson([
                    'code' => 1,
                    'msg' => '版本不正确，请刷新页面再重试',
                ]);
            $this->renderJson($this->doUpdate($target_version));

            $this->renderJson([
                'code' => 0,
                'msg' => '版本更新成功，已更新至v' . $target_version,
            ]);
        }
    }

    private function doUpdate($version)
    {
        $src_url = "http://cloud.zjhejiang.com/we7/mall/update/{$version}/src.zip";
        $db_url = "http://cloud.zjhejiang.com/we7/mall/update/{$version}/db.sql";
        $src_file = dirname(\Yii::$app->basePath) . "/temp/update/{$version}/src.zip";
        $db_file = dirname(\Yii::$app->basePath) . "/temp/update/{$version}/db.sql";

        $timeout = 60 * 30;
        set_time_limit($timeout);
        $core_dir = dirname(\Yii::$app->basePath) . '/core';


        if (file_exists($src_file))
            $res1 = true;
        else
            $res1 = $this->httpcopy($src_url, $src_file, $timeout);

        if (file_exists($db_file))
            $res2 = true;
        else
            $res2 = $this->httpcopy($db_url, $db_file, $timeout);

        if ($res1 == false || $res2 == false)
            $this->renderJson([
                'code' => 1,
                'msg' => '安装失败，从远程服务器下载文件失败，请检查服务器网络是否正常，网站目录是否有写入权限',
            ]);
        \Yii::$app->db->createCommand(file_get_contents($db_file))->execute();
        $zip = Zip::open($src_file);
        $zip->extract($core_dir);
        $zip->close();
        $this->renderJson([
            'code' => 0,
            'msg' => '版本更新成功，已更新至v' . $version,
        ]);

    }


    private function httpcopy($url, $file = "", $timeout = 60)
    {
        $file = empty($file) ? pathinfo($url, PATHINFO_BASENAME) : $file;
        $dir = pathinfo($file, PATHINFO_DIRNAME);
        !is_dir($dir) && @mkdir($dir, 0755, true);
        $url = str_replace(" ", "%20", $url);

        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            $temp = curl_exec($ch);
            if (@file_put_contents($file, $temp) && !curl_error($ch)) {
                return $file;
            } else {
                return false;
            }
        } else {
            $opts = array(
                "http" => array(
                    "method" => "GET",
                    "header" => "",
                    "timeout" => $timeout)
            );
            $context = stream_context_create($opts);
            if (@copy($url, $file, $context)) {
                //$http_response_header
                return $file;
            } else {
                return false;
            }
        }
    }
}