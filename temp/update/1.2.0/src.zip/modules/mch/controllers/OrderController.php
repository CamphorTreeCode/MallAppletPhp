<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/7/20
 * Time: 14:27
 */

namespace app\modules\mch\controllers;


use app\models\Order;
use app\modules\api\models\OrderRevokeForm;
use app\modules\mch\models\OrderListForm;
use app\modules\mch\models\OrderRefundForm;
use app\modules\mch\models\OrderRefundListForm;
use app\modules\mch\models\OrderSendForm;
use app\modules\mch\models\StoreDataForm;

class OrderController extends Controller
{
    public function actionIndex()
    {
        $form = new OrderListForm();
        $form->attributes = \Yii::$app->request->get();
        $form->store_id = $this->store->id;
        $form->limit = 10;
        $data = $form->search();

        $store_data_form = new StoreDataForm();
        $store_data_form->store_id = $this->store->id;
        return $this->render('index', [
            'row_count' => $data['row_count'],
            'pagination' => $data['pagination'],
            'list' => $data['list'],
            //'count_data' => OrderListForm::getCountData($this->store->id),
            'store_data' => $store_data_form->search(),
            'express_list' => $this->getExpressList(),
        ]);
    }

    //订单发货
    public function actionSend()
    {
        $form = new OrderSendForm();
        $form->attributes = \Yii::$app->request->post();
        $form->store_id = $this->store->id;
        $this->renderJson($form->save());
    }

    private function getExpressList()
    {
        $store_express_list = Order::find()
            ->select('express')
            ->where([
                'AND',
                ['store_id' => $this->store->id],
                ['is_send' => 1],
                ['!=', 'express', ''],
            ])->groupBy('express')->orderBy('send_time DESC')->limit('3')->asArray()->all();
        $express_list = [
            '顺丰速运',
            'EMS',
            '申通快递',
            '圆通快递',
            '中通快递',
            '韵达快递',
            '百世汇通快递',
            '宅急送快递',
            '天天快递',
            '德邦物流',
        ];
        $new_store_express_list = [];
        foreach ($store_express_list as $i => $item)
            $new_store_express_list[] = $item['express'];
        return [
            'private' => $new_store_express_list,
            'public' => $express_list,
        ];
    }

    //售后订单列表
    public function actionRefund()
    {
        if (\Yii::$app->request->isPost) {
            $form = new OrderRefundForm();
            $form->attributes = \Yii::$app->request->post();
            $form->store_id = $this->store->id;
            $this->renderJson($form->save());
        } else {
            $form = new OrderRefundListForm();
            $form->attributes = \Yii::$app->request->get();
            $form->store_id = $this->store->id;
            $form->limit = 10;
            $data = $form->search();

            return $this->render('refund', [
                'row_count' => $data['row_count'],
                'pagination' => $data['pagination'],
                'list' => $data['list'],
            ]);
        }
    }

    //订单取消申请处理
    public function actionApplyDeleteStatus($id, $status)
    {
        $order = Order::findOne([
            'id' => $id,
            'apply_delete' => 1,
            'is_delete' => 0,
            'store_id' => $this->store->id,
        ]);
        if (!$order) {
            $this->renderJson([
                'code' => 1,
                'msg' => '订单不存在，请刷新页面后重试',
            ]);
        }
        if ($status == 1) {//同意
            $form = new OrderRevokeForm();
            $form->order_id = $order->id;
            $form->delete_pass = true;
            $form->user_id = $order->user_id;
            $form->store_id = $order->store_id;
            $res = $form->save();
            if ($res['code'] == 0) {
                $this->renderJson([
                    'code' => 0,
                    'msg' => '操作成功',
                ]);
            } else {
                $this->renderJson($res);
            }
        } else {//拒绝
            $order->apply_delete = 0;
            $order->save();
            $this->renderJson([
                'code' => 0,
                'msg' => '操作成功',
            ]);
        }
    }
}