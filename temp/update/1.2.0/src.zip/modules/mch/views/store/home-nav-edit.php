<?php
defined('YII_RUN') or exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/27
 * Time: 11:36
 */

$urlManager = Yii::$app->urlManager;
$this->title = '导航图标编辑';
$this->params['active_nav_group'] = 1;
?>
<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/home-nav']) ?>">导航图标</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>

<div class="main-body p-3">
    <form class="form auto-submit-form" method="post" autocomplete="off"
          data-return="<?= $urlManager->createUrl(['mch/store/home-nav']) ?>">
        <div class="form-title">导航图标编辑</div>
        <div class="form-body">

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class="col-form-label required">名称</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="text" name="model[name]" value="<?= $model['name'] ?>">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">排序</label>
                </div>
                <div class="col-9">
                    <input class="form-control" type="number" name="model[sort]"
                           value="<?= $model['sort'] ? $model['sort'] : 100 ?>">
                </div>
            </div>


            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label required">图标</label>
                </div>
                <div class="col-9">
                    <?= \app\widgets\ImageUpload::widget([
                        'name' => 'model[pic_url]',
                        'value' => $model['pic_url'],
                        'width' => 88,
                        'height' => 88,
                    ]) ?>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">页面url</label>
                </div>
                <div class="col-9">
                    <input class="form-control" name="model[url]" value="<?= $model['url'] ?>">
                    <div class="fs-sm"><a href="http://cloud.zjhejiang.com/we7/mall/" target="_blank">查看帮助文档</a></div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-3 text-right">
                    <label class=" col-form-label">open-type</label>
                </div>
                <div class="col-9">
                    <?php $open_type_list = ['navigate', 'redirect', 'switchTab', 'reLaunch', 'navigateBack',] ?>
                    <select class="form-control" name="model[open_type]">
                        <?php foreach ($open_type_list as $open_type): ?>
                            <option <?= $open_type == $model['open_type'] ? 'selected' : null ?>><?= $open_type ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-9 offset-sm-3">
                    <div class="text-danger form-error mb-3" style="display: none">错误信息</div>
                    <div class="text-success form-success mb-3" style="display: none">成功信息</div>
                    <a class="btn btn-primary submit-btn" href="javascript:">保存</a>
                </div>
            </div>
        </div>

    </form>

</div>