<?php
defined('YII_RUN') or exit('Access Denied');
use yii\widgets\LinkPager;

$urlManager = Yii::$app->urlManager;
$this->title = '系统更新';
$this->params['active_nav_group'] = 1;
?>

<div class="main-nav" flex="cross:center dir:left box:first">
    <div>
        <nav class="breadcrumb rounded-0 mb-0" flex="cross:center">
            <a class="breadcrumb-item" href="<?= $urlManager->createUrl(['mch/store/index']) ?>">我的商城</a>
            <span class="breadcrumb-item active"><?= $this->title ?></span>
        </nav>
    </div>
    <div>
        <?= $this->render('/layouts/nav-right') ?>
    </div>
</div>

<div class="main-body p-3">
    <div class="card" style="max-width: 60rem;margin-bottom: 2rem">
        <div class="card-block">
            <p>当前系统版本：v<?= $version ?></p>
            <hr>
            <div>
                <?php if ($next_version): ?>
                    <div>版本更新：v<?= $next_version->version ?></div>
                    <div>更新时间：<?= $next_version->datetime ?></div>
                    <div>更新说明：<?= $next_version->desc ?></div>
                    <div class="card mt-3" style="max-width: 30rem">
                        <div class="card-block text-center">
                            <div class="mt-3">
                                <div class="progress mb-2">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                         role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 0%">0%
                                    </div>
                                </div>
                                <div class="text-warning">更新过程请勿关闭或刷新页面</div>
                                <div class="alert alert-danger" style="display: none" role="alert"></div>
                                <div class="alert alert-success" style="display: none" role="alert"></div>
                            </div>
                            <a class="btn btn-primary btn-sm mt-3 update-btn" href="javascript:">立即更新</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div>暂无新版本</div>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <div class="card" style="max-width: 60rem">
        <div class="card-block">
            <b>更新记录</b>
            <hr>
            <?php foreach ($version_list as $item): ?>
                <div>
                    <div>版本：v<?= $item->version ?></div>
                    <div>时间：<?= $item->datetime ?></div>
                    <div>内容：<br><?= $item->desc ?></div>
                    <hr>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<script>
    $(document).on("click", ".update-btn", function () {
        if (!confirm('警告：更新前请确认您已做好了相关数据备份！点击确定开始更新系统'))
            return;
        window.onbeforeunload = function () {
            return "系统更新还没完成，确认关闭页面？";
        };
        var btn = $(this);
        var error = $(".alert-danger");
        var success = $(".alert-success");
        var progress_bar = $(".progress-bar");

        progress_bar.css("width", "0%");
        progress_bar.text("0%");
        error.hide();
        success.hide();


        var init_width = 1;
        progress_bar.css("width", init_width + "%");
        progress_bar.text(init_width + "%");
        var timer = setInterval(function () {
            if (init_width >= 90) {
                clearInterval(timer);
                return;
            }
            init_width++;
            progress_bar.css("width", init_width + "%");
            progress_bar.text(init_width + "%");
        }, 1000);
        btn.btnLoading("正在更新");
        $.ajax({
            url: "<?=$urlManager->createUrl(['mch/update/update'])?>",
            type: "post",
            timeout: 60 * 30 * 1000,
            data: {
                target_version: "<?= $next_version->version ?>",
                _csrf: _csrf
            },
            success: function (res) {
                clearInterval(timer);
                window.onbeforeunload = null;
                if (res.code == 0) {
                    progress_bar.css("width", "100%");
                    progress_bar.text("100%");
                    success.html(res.msg).show();
                    btn.hide();
                }
                if (res.code == 1) {
                    error.html(res.msg).show();
                    btn.btnReset();
                }
            },
        });

    });
</script>