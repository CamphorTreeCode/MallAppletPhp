<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/7
 * Time: 12:59
 */

namespace app\modules\mch\models;


use app\models\Goods;
use app\models\GoodsPic;
use yii\data\Pagination;

class GoodsForm extends Model
{
    public $goods;

    public $store_id;
    public $name;
    public $goods_pic_list;
    public $cat_id;
    public $price;
    public $original_price;
    public $service;
    public $detail;

    /**
     * @return array
     */
    public function rules()
    {
        return [
            [['service'], 'trim'],
            [['store_id', 'name', 'price', 'cat_id', 'detail', 'goods_pic_list'], 'required'],
            [['store_id',], 'integer'],
            [['price', 'original_price'], 'number'],
            [['price',], 'number', 'min' => 0.01,],
            [['detail', 'service',], 'string'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'store_id' => 'Store ID',
            'name' => '商品名称',
            'price' => '售价',
            'original_price' => '原价（只做显示用）',
            'detail' => '图文详情',
            'cat_id' => '商品分类',
            'status' => '上架状态：0=下架，1=上架',
            'goods_pic_list' => '商品图片',
        ];
    }

    /**
     *
     */
    public function getList($store_id)
    {
        $query = Goods::find()
            ->alias('g')
            ->andWhere(['g.is_delete' => 0, 'g.store_id' => $store_id]);
        $count = $query->count();
        $p = new Pagination(['totalCount' => $count, 'pageSize' => 20]);

        $list = $query
            ->select(['g.*', 'c.name AS cname'])
            ->leftJoin('{{%cat}} c', 'g.cat_id=c.id')
            ->orderBy('g.addtime DESC')
            ->offset($p->offset)
            ->limit($p->limit)
            ->asArray()
            ->all();
        return [$list, $p];
    }

    /**
     * 编辑
     * @return array
     */
    public function save()
    {
        if ($this->validate()) {
            if (!is_array($this->goods_pic_list) || empty($this->goods_pic_list) || count($this->goods_pic_list) == 0)
                return [
                    'code' => 1,
                    'msg' => '商品图片不能为空',
                ];
            if (!$this->original_price)
                $this->original_price = $this->price;
            $goods = $this->goods;
            if ($goods->isNewRecord) {
                $goods->is_delete = 0;
                $goods->addtime = time();
                $goods->status = 0;
                $goods->attr = json_encode([], JSON_UNESCAPED_UNICODE);
            }
            $goods->attributes = $this->attributes;
            if ($goods->save()) {
                GoodsPic::updateAll(['is_delete' => 1], ['goods_id' => $goods->id]);
                foreach ($this->goods_pic_list as $pic_url) {
                    $goods_pic = new GoodsPic();
                    $goods_pic->goods_id = $goods->id;
                    $goods_pic->pic_url = $pic_url;
                    $goods_pic->is_delete = 0;
                    $goods_pic->save();
                }
                return [
                    'code' => 0,
                    'msg' => '保存成功',
                ];
            } else {
                return $this->getModelError($goods);
            }
        } else {
            return $this->getModelError();
        }
    }
}