<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/8
 * Time: 18:30
 */

namespace app\modules\mch\models;


use app\models\Setting;

/**
 * @property \app\models\Setting $list;
 */
class ShareBasicForm extends Model
{
    public $list;
    public $store_id;

    public $level;
    public $condition;
    public $share_condition;
    public $content;
    public $pay_type;
    public $agree;
    public $min_money;

    public function rules()
    {
        return [
            [['level','condition','share_condition','pay_type'],'integer'],
            [['content','agree'],'trim'],
            [['pay_type'],'default','value'=>1],
            [['min_money'],'number','min'=>1,'max'=>999999],
        ];
    }
    public function attributeLabels()
    {
        return [
            'min_money'=>'最小提现金额',
            'content'=>'用户须知',
            'agree'=>'申请协议',
        ];
    }

    public function save()
    {
        if($this->validate()){
            $list = $this->list;
            if($list->isNewRecord){
                $list->store_id = $this->store_id;
                $list->first = 0;
                $list->second = 0;
                $list->third = 0;
            }
            $list->attributes = $this->attributes;
            if ($list->save()) {
                return [
                    'code' => 0,
                    'msg' => '成功'
                ];
            } else {
                return [
                    'code' => 1,
                    'msg' => '失败',
                    'data'=>$list->errors
                ];
            }
        }else{
            return $this->getModelError();
        }
    }
}